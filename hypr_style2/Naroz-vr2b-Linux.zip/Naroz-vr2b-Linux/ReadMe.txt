Naroz Cursor (vr2b) for Linux.

Created by MOYASH.

------------------------

to install: 

1-Move "Naroz-vr2b" folder to the ".icons" folder in your "Home" directory.

2-Then Choose and Apply the Cursor Name.

---------------------------------------------------

License:(CC BY-NC-ND).

---------------------------

Thanks for Downloading my Work.